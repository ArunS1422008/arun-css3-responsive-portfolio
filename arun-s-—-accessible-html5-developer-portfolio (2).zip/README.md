# Arun S — Accessible HTML5 Developer Portfolio

**Thiranex Internship · Task 1: HTML5 Semantic Structure & Accessibility**

A complete, responsive, multi-page personal portfolio built with semantic HTML5, CSS3, and progressive-enhancement vanilla JavaScript for **Arun S** (2nd Year, B.E. Computer Science and Engineering, Easwari Engineering College, Chennai).

---

## Pages Included

1. **Home (`index.html`)** — Hero introduction, quick academic highlights, selected project previews, and engineering approach aside.
2. **About Me (`about.html`)** — Academic journey, core engineering principles, education milestones, and student profile snapshot.
3. **Skills (`skills.html`)** — Core skill domains, accessible proficiency matrix table (`<caption class="sr-only">`, `<th scope="col/row">`, `role="progressbar"`), and accessibility testing routine.
4. **Projects (`projects.html`)** — Interactive category filter (`aria-pressed`, `aria-live="polite"`), project cards with descriptive `alt` text, and an accessible specification modal (`role="dialog"`, `aria-modal="true"`, Escape key closing).
5. **Certifications (`certifications.html`)** — Filterable directory of 6 academic and technical credentials.
6. **Contact (`contact.html`)** — Validated contact form (Name, Email, Subject, Message) featuring explicit `<label>` bindings, `aria-describedby` hints/errors, `aria-invalid` states, focusable error summary (`role="alert"`), and live confirmation status.

---

## Folder Structure

```text
arun-html5-accessible-portfolio/
├── index.html
├── about.html
├── skills.html
├── projects.html
├── certifications.html
├── contact.html
├── css/
│   └── styles.css
├── js/
│   └── main.js
├── src/
│   └── assets/
│       └── images/
└── README.md
```

---

## Accessibility & SEO Checklist

- **Semantic HTML5 Landmarks**: Every page uses `<header>`, `<nav>`, `<main>`, `<section>`, `<article>`, `<aside>` (where appropriate), and `<footer>`.
- **Skip-to-Content Link**: First focusable element on every page jumps directly to `#main-content`.
- **Keyboard Navigation & Focus**: High-contrast `:focus-visible` outlines (`3px solid #1d4ed8` with `3px` offset) and full `Tab` / `Shift+Tab` / `Enter` / `Escape` support.
- **Heading Hierarchy**: Strictly one `<h1>` per page followed by sequential `<h2>` and `<h3>` headings.
- **Color Contrast**: Primary text (`#0f172a`) on warm paper canvas (`#faf9f6`) exceeds 15:1 contrast; cobalt accent (`#1d4ed8`) exceeds 6.5:1.
- **Reduced Motion**: Honors `@media (prefers-reduced-motion: reduce)`.
- **SEO Metadata**: Unique `<title>`, `<meta name="description">`, OpenGraph, Twitter Cards, and Schema.org JSON-LD.

---

## Running Locally

Open `index.html` directly in Google Chrome, or use the **Live Server** extension in Visual Studio Code (`Go Live` from the bottom status bar) to test all 6 pages, keyboard navigation, and form validation.
